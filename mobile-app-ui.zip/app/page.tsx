"use client"

import { useState } from "react"
import { Home, Search, User, Map, Heart } from "lucide-react"
import HomeScreen from "@/components/screens/home-screen"
import CheckoutScreen from "@/components/screens/checkout-screen"
import MapScreen from "@/components/screens/map-screen"
import AnalyticsScreen from "@/components/screens/analytics-screen"
import SocialScreen from "@/components/screens/social-screen"
import ChatScreen from "@/components/screens/chat-screen"
import ProfileScreen from "@/components/screens/profile-screen"

export default function App() {
  const [activeScreen, setActiveScreen] = useState("home")

  const renderScreen = () => {
    switch (activeScreen) {
      case "home":
        return <HomeScreen />
      case "checkout":
        return <CheckoutScreen />
      case "map":
        return <MapScreen />
      case "analytics":
        return <AnalyticsScreen />
      case "social":
        return <SocialScreen />
      case "chat":
        return <ChatScreen />
      case "profile":
        return <ProfileScreen />
      default:
        return <HomeScreen />
    }
  }

  return (
    <div className="max-w-md mx-auto h-[844px] bg-white relative overflow-hidden">
      {renderScreen()}

      {activeScreen !== "checkout" && activeScreen !== "profile" && (
        <div className="absolute bottom-0 left-0 right-0 flex justify-around items-center h-16 border-t border-[#e6e6e6] bg-white">
          <button
            onClick={() => setActiveScreen("home")}
            className={`flex flex-col items-center justify-center w-12 h-12 ${activeScreen === "home" ? "text-black" : "text-[#828282]"}`}
          >
            <Home size={24} />
          </button>
          <button
            onClick={() => setActiveScreen("search")}
            className={`flex flex-col items-center justify-center w-12 h-12 ${activeScreen === "search" ? "text-black" : "text-[#828282]"}`}
          >
            <Search size={24} />
          </button>
          <button
            onClick={() => setActiveScreen("map")}
            className={`flex flex-col items-center justify-center w-12 h-12 ${activeScreen === "map" ? "text-black" : "text-[#828282]"}`}
          >
            <Map size={24} />
          </button>
          <button
            onClick={() => setActiveScreen("social")}
            className={`flex flex-col items-center justify-center w-12 h-12 ${activeScreen === "social" ? "text-black" : "text-[#828282]"}`}
          >
            <Heart size={24} />
          </button>
          <button
            onClick={() => setActiveScreen("profile")}
            className={`flex flex-col items-center justify-center w-12 h-12 ${activeScreen === "profile" ? "text-black" : "text-[#828282]"}`}
          >
            <User size={24} />
          </button>
        </div>
      )}
    </div>
  )
}

