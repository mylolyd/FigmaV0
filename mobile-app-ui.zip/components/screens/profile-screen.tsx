import { ArrowLeft, Send } from "lucide-react"
import Image from "next/image"

export default function ProfileScreen() {
  return (
    <div className="h-full overflow-y-auto">
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center">
          <button className="mr-4">
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-lg font-semibold">App name</h1>
        </div>
        <div className="flex items-center space-x-4">
          <button>
            <Image src="/placeholder.svg?height=24&width=24" alt="Call" width={24} height={24} className="w-6 h-6" />
          </button>
          <button>
            <Image src="/placeholder.svg?height=24&width=24" alt="Video" width={24} height={24} className="w-6 h-6" />
          </button>
        </div>
      </div>

      <div className="bg-[#f7f7f7] p-4 rounded-lg mx-4 mb-4">
        <div className="flex items-center">
          <div className="w-12 h-12 rounded-full overflow-hidden mr-3">
            <Image
              src="/placeholder.svg?height=48&width=48"
              alt="Profile"
              width={48}
              height={48}
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <h2 className="font-semibold">Helena Hills</h2>
            <p className="text-xs text-[#828282]">Online</p>
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="bg-black text-white rounded-lg p-3 mb-4 max-w-[80%]">
          <p className="text-sm">This is the main chat template.</p>
        </div>

        <div className="flex justify-end mb-4">
          <div className="bg-[#f7f7f7] rounded-lg p-3 max-w-[80%]">
            <p className="text-sm">Create an account</p>
            <p className="text-xs text-[#828282] mt-1">Nov 20, 2023, 9:41 AM</p>
          </div>
        </div>

        <div className="flex justify-end mb-4">
          <div className="bg-[#f7f7f7] rounded-lg p-3 max-w-[80%]">
            <p className="text-sm">Enter your email to sign up for this app</p>
          </div>
        </div>

        <div className="flex mb-4">
          <div className="bg-[#f7f7f7] rounded-lg p-3 max-w-[80%]">
            <p className="text-sm">email@example.com</p>
          </div>
        </div>

        <div className="flex justify-between items-center mb-4">
          <div className="w-1/3 h-px bg-[#e6e6e6]"></div>
          <div className="text-xs text-[#828282]">OR</div>
          <div className="w-1/3 h-px bg-[#e6e6e6]"></div>
        </div>

        <div className="flex mb-4">
          <div className="bg-[#f7f7f7] rounded-lg p-3 max-w-[80%]">
            <p className="text-sm">Cont.</p>
          </div>
        </div>

        <div className="flex justify-end mb-4">
          <div className="bg-[#f7f7f7] rounded-lg p-3 max-w-[80%]">
            <p className="text-sm">How does it work?</p>
          </div>
        </div>

        <div className="flex items-center mb-4">
          <div className="w-8 h-8 rounded-full overflow-hidden mr-2">
            <Image
              src="/placeholder.svg?height=32&width=32"
              alt="Profile"
              width={32}
              height={32}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="bg-[#f7f7f7] rounded-lg p-3 max-w-[80%]">
            <p className="text-sm">
              You just add any text to type in the conversation you want to know about, and I'll try to help.
            </p>
          </div>
        </div>
      </div>

      <div className="p-4 border-t border-[#e6e6e6] mt-auto">
        <div className="flex items-center">
          <input type="text" placeholder="Message..." className="flex-1 bg-[#f7f7f7] rounded-full py-2 px-4 mr-2" />
          <button className="bg-[#f7f7f7] w-10 h-10 rounded-full flex items-center justify-center">
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  )
}

