import { Search, Filter, ArrowLeft } from "lucide-react"
import Image from "next/image"

export default function MapScreen() {
  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b border-[#e6e6e6]">
        <div className="flex items-center mb-4">
          <button className="mr-2">
            <ArrowLeft size={20} />
          </button>
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#828282]" size={18} />
            <input
              type="text"
              value="San Francisco"
              className="w-full pl-10 pr-4 py-2 bg-[#f7f7f7] rounded-full text-sm"
              readOnly
            />
          </div>
          <button className="ml-2">
            <Filter size={20} />
          </button>
        </div>

        <div className="flex justify-between text-sm">
          <div className="text-[#828282]">Sep 12-20 • 1 room • 2 guests</div>
          <div className="flex space-x-4">
            <button className="font-medium">Filter</button>
            <button className="font-medium">Sort</button>
          </div>
        </div>

        <div className="mt-2 text-sm">
          <span className="font-medium">99 results</span>
        </div>
      </div>

      <div className="flex-1 relative">
        <div className="absolute inset-0 bg-[#f7f7f7]">
          <Image
            src="/placeholder.svg?height=500&width=400"
            alt="Map"
            width={400}
            height={500}
            className="w-full h-full object-cover"
          />
        </div>

        <div className="absolute top-1/4 left-1/4">
          <div className="bg-white rounded-lg shadow-md px-2 py-1 text-xs font-semibold">$199</div>
        </div>

        <div className="absolute top-1/3 left-1/2">
          <div className="bg-white rounded-lg shadow-md px-2 py-1 text-xs font-semibold">$239</div>
        </div>

        <div className="absolute top-1/2 left-1/3">
          <div className="bg-black text-white rounded-lg shadow-md px-2 py-1 text-xs font-semibold">$125</div>
        </div>

        <div className="absolute top-2/3 left-1/4">
          <div className="bg-white rounded-lg shadow-md px-2 py-1 text-xs font-semibold">$178</div>
        </div>

        <div className="absolute top-1/2 left-2/3">
          <div className="bg-white rounded-lg shadow-md px-2 py-1 text-xs font-semibold">$257</div>
        </div>

        <div className="absolute bottom-32 left-1/2">
          <div className="bg-white rounded-lg shadow-md px-2 py-1 text-xs font-semibold">$345</div>
        </div>

        <div className="absolute bottom-0 left-0 right-0">
          <div className="p-4">
            <div className="flex space-x-4 overflow-x-auto pb-4">
              <div className="flex-shrink-0 w-64 bg-white rounded-lg shadow-md overflow-hidden">
                <Image
                  src="/placeholder.svg?height=120&width=240"
                  alt="Location"
                  width={240}
                  height={120}
                  className="w-full h-32 object-cover"
                />
                <div className="p-3">
                  <h3 className="font-medium">Location name</h3>
                  <div className="flex items-center text-xs text-[#828282] mt-1">
                    <span>4.8 (120 reviews)</span>
                    <span className="mx-2">•</span>
                    <span>1.2 miles</span>
                  </div>
                  <div className="flex justify-between items-center mt-2">
                    <div className="text-sm font-semibold">
                      $123 <span className="text-xs font-normal text-[#828282]">night</span>
                    </div>
                    <button className="bg-black text-white text-xs px-3 py-1 rounded-full">Select</button>
                  </div>
                </div>
              </div>

              <div className="flex-shrink-0 w-64 bg-white rounded-lg shadow-md overflow-hidden">
                <Image
                  src="/placeholder.svg?height=120&width=240"
                  alt="Location"
                  width={240}
                  height={120}
                  className="w-full h-32 object-cover"
                />
                <div className="p-3">
                  <h3 className="font-medium">Location name</h3>
                  <div className="flex items-center text-xs text-[#828282] mt-1">
                    <span>4.9 (85 reviews)</span>
                    <span className="mx-2">•</span>
                    <span>0.8 miles</span>
                  </div>
                  <div className="flex justify-between items-center mt-2">
                    <div className="text-sm font-semibold">
                      $145 <span className="text-xs font-normal text-[#828282]">night</span>
                    </div>
                    <button className="bg-black text-white text-xs px-3 py-1 rounded-full">Select</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

