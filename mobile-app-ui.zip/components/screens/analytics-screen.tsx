import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Image from "next/image"

export default function AnalyticsScreen() {
  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b border-[#e6e6e6] flex items-center">
        <h1 className="text-lg font-semibold flex-1 text-center">App name</h1>
        <div className="w-8 h-8 rounded-full overflow-hidden">
          <Image
            src="/placeholder.svg?height=32&width=32"
            alt="Profile"
            width={32}
            height={32}
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      <Tabs defaultValue="tab1" className="flex-1 flex flex-col">
        <div className="border-b border-[#e6e6e6]">
          <TabsList className="flex w-full bg-transparent p-0">
            <TabsTrigger
              value="tab1"
              className="flex-1 py-3 rounded-none data-[state=active]:border-b-2 data-[state=active]:border-black"
            >
              Tab
            </TabsTrigger>
            <TabsTrigger
              value="tab2"
              className="flex-1 py-3 rounded-none data-[state=active]:border-b-2 data-[state=active]:border-black"
            >
              Tab
            </TabsTrigger>
            <TabsTrigger
              value="tab3"
              className="flex-1 py-3 rounded-none data-[state=active]:border-b-2 data-[state=active]:border-black"
            >
              Tab
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="tab1" className="flex-1 p-4 overflow-y-auto">
          <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
            <h2 className="text-sm text-[#828282] mb-1">Title</h2>
            <div className="flex items-baseline">
              <span className="text-2xl font-bold">$45,678.90</span>
              <span className="text-xs text-[#828282] ml-2">+20% month over month</span>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
            <h2 className="text-sm text-[#828282] mb-1">Title</h2>
            <div className="flex items-baseline">
              <span className="text-2xl font-bold">2,405</span>
              <span className="text-xs text-[#828282] ml-2">+13% month over month</span>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
            <h2 className="text-sm text-[#828282] mb-1">Title</h2>
            <div className="h-40 mt-4">
              <Image
                src="/placeholder.svg?height=160&width=340"
                alt="Chart"
                width={340}
                height={160}
                className="w-full h-full object-contain"
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="tab2" className="flex-1 p-4 overflow-y-auto">
          <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
            <h2 className="text-sm text-[#828282] mb-1">Tab 2 Content</h2>
          </div>
        </TabsContent>

        <TabsContent value="tab3" className="flex-1 p-4 overflow-y-auto">
          <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
            <h2 className="text-sm text-[#828282] mb-1">Tab 3 Content</h2>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

