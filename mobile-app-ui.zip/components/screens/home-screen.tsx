import { Search, History, Star, ChevronRight } from "lucide-react"
import Image from "next/image"

export default function HomeScreen() {
  return (
    <div className="h-full overflow-y-auto pb-16">
      <div className="p-4">
        <div className="flex items-center mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#828282]" size={18} />
            <input
              type="text"
              placeholder="Search"
              className="w-full pl-10 pr-4 py-2 bg-[#f7f7f7] rounded-full text-sm"
            />
          </div>
        </div>

        <div className="flex space-x-4 mb-4">
          <button className="flex items-center space-x-1 px-3 py-1 bg-[#f7f7f7] rounded-full text-sm">
            <Search size={16} />
            <span>Favorites</span>
          </button>
          <button className="flex items-center space-x-1 px-3 py-1 bg-[#f7f7f7] rounded-full text-sm">
            <History size={16} />
            <span>History</span>
          </button>
          <button className="flex items-center space-x-1 px-3 py-1 bg-[#f7f7f7] rounded-full text-sm">
            <Star size={16} />
            <span>Following</span>
          </button>
        </div>

        <div className="relative mb-6 rounded-lg overflow-hidden">
          <Image
            src="/placeholder.svg?height=150&width=380"
            alt="Banner"
            width={380}
            height={150}
            className="w-full h-[150px] object-cover"
          />
          <div className="absolute bottom-0 left-0 p-4">
            <h2 className="text-lg font-semibold text-white">Banner title</h2>
          </div>
        </div>

        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <h3 className="font-semibold">Title</h3>
            <ChevronRight size={18} className="text-[#828282]" />
          </div>
          <div className="flex space-x-3 overflow-x-auto pb-2">
            {[1, 2, 3, 4].map((item) => (
              <div key={item} className="flex-shrink-0 w-20">
                <div className="w-20 h-20 bg-[#f7f7f7] rounded-lg mb-1">
                  <Image
                    src="/placeholder.svg?height=80&width=80"
                    alt="Product"
                    width={80}
                    height={80}
                    className="w-full h-full object-cover rounded-lg"
                  />
                </div>
                <p className="text-xs text-center">Title</p>
              </div>
            ))}
          </div>
        </div>

        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <h3 className="font-semibold">Title</h3>
            <ChevronRight size={18} className="text-[#828282]" />
          </div>
          <div className="grid grid-cols-4 gap-3">
            {[1, 2, 3, 4].map((item) => (
              <div key={item} className="flex-shrink-0">
                <div className="aspect-square bg-[#f7f7f7] rounded-lg mb-1">
                  <Image
                    src="/placeholder.svg?height=80&width=80"
                    alt="Product"
                    width={80}
                    height={80}
                    className="w-full h-full object-cover rounded-lg"
                  />
                </div>
                <p className="text-xs text-center">Title</p>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="flex justify-between items-center mb-2">
            <h3 className="font-semibold">Title</h3>
            <ChevronRight size={18} className="text-[#828282]" />
          </div>
          <div className="grid grid-cols-3 gap-3">
            {[1, 2, 3, 4, 5, 6].map((item) => (
              <div key={item} className="flex-shrink-0">
                <div className="aspect-square bg-[#f7f7f7] rounded-lg mb-1">
                  <Image
                    src="/placeholder.svg?height=100&width=100"
                    alt="Product"
                    width={100}
                    height={100}
                    className="w-full h-full object-cover rounded-lg"
                  />
                </div>
                <p className="text-xs">Product name</p>
                <p className="text-xs font-semibold">$19.99</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

