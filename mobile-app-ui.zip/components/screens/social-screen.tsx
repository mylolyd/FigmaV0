import { Heart, MessageCircle, MoreHorizontal } from "lucide-react"
import Image from "next/image"

export default function SocialScreen() {
  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b border-[#e6e6e6] flex items-center">
        <h1 className="text-lg font-semibold flex-1">Activity</h1>
        <div className="flex space-x-4">
          <button>For you</button>
          <button className="text-[#828282]">Favorites</button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="border-b border-[#e6e6e6] p-4">
          <div className="flex items-center mb-3">
            <div className="w-10 h-10 rounded-full overflow-hidden mr-3">
              <Image
                src="/placeholder.svg?height=40&width=40"
                alt="Profile"
                width={40}
                height={40}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex-1">
              <div className="flex items-center">
                <h3 className="font-semibold text-sm">Helena in Group name</h3>
                <span className="text-xs text-[#828282] ml-2">1 day ago</span>
              </div>
            </div>
            <button>
              <MoreHorizontal size={20} />
            </button>
          </div>

          <div className="mb-3">
            <Image
              src="/placeholder.svg?height=300&width=380"
              alt="Post"
              width={380}
              height={300}
              className="w-full rounded-lg"
            />
          </div>

          <div className="mb-2">
            <p className="text-sm">Post description</p>
          </div>

          <div className="flex items-center text-sm">
            <button className="flex items-center mr-4">
              <Heart size={16} className="mr-1" />
              <span>21 likes</span>
            </button>
            <button className="flex items-center">
              <MessageCircle size={16} className="mr-1" />
              <span>4 comments</span>
            </button>
          </div>
        </div>

        <div className="p-4">
          <div className="flex items-center mb-3">
            <div className="w-10 h-10 rounded-full overflow-hidden mr-3">
              <Image
                src="/placeholder.svg?height=40&width=40"
                alt="Profile"
                width={40}
                height={40}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex-1">
              <div className="flex items-center">
                <h3 className="font-semibold text-sm">Daniel in Group Name</h3>
                <span className="text-xs text-[#828282] ml-2">2 days ago</span>
              </div>
            </div>
            <button>
              <MoreHorizontal size={20} />
            </button>
          </div>

          <div className="mb-2">
            <p className="text-sm">
              Body text for a post. Since it's a social app, and sometimes it's not just, and sometimes it's a question.
            </p>
          </div>

          <div className="flex items-center text-sm">
            <button className="flex items-center mr-4">
              <Heart size={16} className="mr-1" />
              <span>9 likes</span>
            </button>
            <button className="flex items-center">
              <MessageCircle size={16} className="mr-1" />
              <span>3 comments</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

