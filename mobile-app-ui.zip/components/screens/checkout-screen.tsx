import { ChevronLeft, ChevronRight } from "lucide-react"

export default function CheckoutScreen() {
  return (
    <div className="h-full overflow-y-auto">
      <div className="p-4 border-b border-[#e6e6e6]">
        <div className="flex items-center">
          <button className="mr-4">
            <ChevronLeft size={24} />
          </button>
          <h1 className="text-lg font-semibold flex-1 text-center">Checkout</h1>
          <div className="w-6"></div>
        </div>
      </div>

      <div className="p-4 border-b border-[#e6e6e6]">
        <div className="flex justify-between items-center mb-2">
          <h2 className="font-medium">SHIPPING ADDRESS</h2>
          <ChevronRight size={18} className="text-[#828282]" />
        </div>
      </div>

      <div className="p-4 border-b border-[#e6e6e6]">
        <div className="flex items-center justify-between mb-2">
          <h2 className="font-medium">DELIVERY</h2>
        </div>
        <div className="flex justify-between items-center text-sm">
          <div>
            <p>Free</p>
            <p className="text-[#828282]">Standard | 3-4 days</p>
          </div>
          <ChevronRight size={18} className="text-[#828282]" />
        </div>
      </div>

      <div className="p-4 border-b border-[#e6e6e6]">
        <div className="flex items-center justify-between mb-2">
          <h2 className="font-medium">PAYMENT</h2>
        </div>
        <div className="flex justify-between items-center text-sm">
          <div>
            <p>Visa *1234</p>
          </div>
          <ChevronRight size={18} className="text-[#828282]" />
        </div>
      </div>

      <div className="p-4 border-b border-[#e6e6e6]">
        <div className="flex items-center justify-between mb-2">
          <h2 className="font-medium">PROMOS</h2>
        </div>
        <div className="flex justify-between items-center text-sm">
          <div>
            <p className="text-[#828282]">Apply promo code</p>
          </div>
          <ChevronRight size={18} className="text-[#828282]" />
        </div>
      </div>

      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-medium">ITEMS</h2>
          <div className="flex space-x-4 text-sm">
            <span>DESCRIPTION</span>
            <span>PRICE</span>
          </div>
        </div>

        <div className="flex items-start mb-4">
          <div className="w-16 h-16 bg-[#f7f7f7] rounded-lg mr-3">
            <Image
              src="/placeholder.svg?height=64&width=64"
              alt="Product"
              width={64}
              height={64}
              className="w-full h-full object-cover rounded-lg"
            />
          </div>
          <div className="flex-1">
            <p className="text-xs text-[#828282]">Item</p>
            <p className="text-sm font-medium">Product name</p>
            <p className="text-xs text-[#828282]">Description</p>
            <p className="text-xs text-[#828282]">Quantity: 01</p>
          </div>
          <div className="text-sm">$15.99</div>
        </div>

        <div className="flex items-start mb-4">
          <div className="w-16 h-16 bg-[#f7f7f7] rounded-lg mr-3">
            <Image
              src="/placeholder.svg?height=64&width=64"
              alt="Product"
              width={64}
              height={64}
              className="w-full h-full object-cover rounded-lg"
            />
          </div>
          <div className="flex-1">
            <p className="text-xs text-[#828282]">Item</p>
            <p className="text-sm font-medium">Product name</p>
            <p className="text-xs text-[#828282]">Description</p>
            <p className="text-xs text-[#828282]">Quantity: 01</p>
          </div>
          <div className="text-sm">$5.99</div>
        </div>

        <div className="border-t border-[#e6e6e6] pt-4 mt-4">
          <div className="flex justify-between text-sm mb-1">
            <span>Subtotal (2)</span>
            <span>$19.98</span>
          </div>
          <div className="flex justify-between text-sm mb-1">
            <span>Shipping total</span>
            <span>Free</span>
          </div>
          <div className="flex justify-between text-sm mb-1">
            <span>Taxes</span>
            <span>$2.00</span>
          </div>
          <div className="flex justify-between font-semibold mt-2">
            <span>Total</span>
            <span>$21.98</span>
          </div>
        </div>
      </div>

      <div className="p-4 mt-auto">
        <button className="w-full bg-black text-white py-3 rounded-lg font-medium">Place order</button>
      </div>
    </div>
  )
}

